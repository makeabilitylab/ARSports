# Low Vision Sports > Basketball-Dataset-Full-Checked
https://universe.roboflow.com/makeabilitysports/low-vision-sports

Provided by a Roboflow user
License: CC BY 4.0

